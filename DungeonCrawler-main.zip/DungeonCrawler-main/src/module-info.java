/**
 * 
 */
/**
 * 
 */
module DungeonCrawler {
	requires java.desktop;
}